# BirZum Haydovchi — APK yig'ish (faqat telefon bilan)

Kuryer ilovasi bilan bir xil yo'l, faqat **alohida repozitoriy** va **alohida Firebase ilova**.

Kerak: GitHub akkaunt, **haydovchi-android.zip**, **haydovchi-build.yml**, Firebase'dan **yangi google-services.json**.

## 0. Firebase'da haydovchi ilovasini qo'shish (bir marta)
Kuryer ilovasi turgan **o'sha Firebase loyihasi**da (sayt shu loyiha kaliti bilan push yuboradi):
1. Firebase Console → ⚙️ **Project settings** → pastda **Add app** → **Android**.
2. **Android package name**: `uz.sdmsys.birzum.driver` (aynan shunday) → **Register app**.
3. **google-services.json** ni yuklab oling. Bu fayl ichida endi ikkala ilova bor — shu yangisini ishlating.

> Saytdagi server kaliti (firebase-adminsdk-....json) o'zgarmaydi. U GitHub'ga YUKLANMAYDI.

## 1. Repozitoriy
github.com → **+** → **New repository** → nomi `birzum-driver` → **Private** → **Create repository**.

## 2. build.yml
1. Repozitoriyda **Add file → Create new file**.
2. Nomiga aynan: `.github/workflows/build.yml`
3. **haydovchi-build.yml** faylini telefonda oching → hammasini nusxalang → katta maydonga qo'ying → **Commit changes**.

## 3. Ikki faylni yuklash
1. **Add file → Upload files**.
2. **haydovchi-android.zip** — **OCHMASDAN**, zipning o'zini.
3. **google-services.json** (0-qadamdagi yangisi).
4. **Commit changes**.

## 4. Yig'ish
1. **Actions** → chapda **Haydovchi APK yig'ish** → **Run workflow**.
2. 5–10 daqiqa. ✅ yashil bo'lsa: run ichiga kiring → **Artifacts** → **birzum-haydovchi-apk** → yuklab oling →
   zipni oching → `app-release.apk` ni o'rnating. (**birzum-haydovchi-aab** — Google Play uchun.)
3. ❌ qizil bo'lsa: sahifa tepasidagi (Summary) o'zbekcha xulosani o'qing.
   - **"google-services.json ichida uz.sdmsys.birzum.driver ilovasi yo'q"** → 0-qadamni bajaring va yangi faylni yuklang.
   - **"Yig'ish yiqildi"** → qutidagi matnni to'liq nusxalab menga yuboring.

## 5. Saytga ulash
1. APK faylni saytga yoki Telegram kanalga yuklang va havolasini oling.
2. Admin → Sozlamalar → **Taksi** → **"Haydovchi ilovasi (APK) havolasi"** ga qo'ying.
   Shundan keyin haydovchi panelida (`sayt/t/`) **"Haydovchi ilovasini o'rnating"** tugmasi chiqadi.

## 6. Birinchi ishga tushirish (haydovchi telefonida)
1. Ilovani oching → ruxsatlarning **hammasiga** "Ruxsat berish": bildirishnoma → joylashuv →
   **"Doim ruxsat berish"** → batareya **"Cheklovsiz"** → ekranda ochilish → avtozapusk (Xiaomi/Redmi va h.k.).
2. Telefon raqami, parol (va PIN) bilan kiring. Bir marta kiriladi.
3. Admin → Taksi → **Haydovchilar**: haydovchi ismi yonida **📱** chiqsa — ilova ulangan, push keladi.

## Ilova nima qiladi
- Haydovchi panelini (`sayt/t/`) ochadi — veb panel bilan bir xil ekranlar.
- Yangi buyurtma kelsa telefon qulflangan bo'lsa ham **sirena** chaladi va ekranni yoqadi (ilova yopiq bo'lsa ham).
- Hisob to'ldirildi, buyurtma bekor qilindi kabi xabarlar — oddiy bildirishnoma (sirenasiz).
- Joylashuvni fonda yuboradi: yo'lovchi haydovchini xaritada ko'radi.
- Qo'ng'iroq, Google/Yandex xarita, to'lov sahifalari telefonning o'z ilovalarida ochiladi.

## Imzo kaliti (Google Play va keyingi yangilanishlar uchun)
Kuryer ilovasidagi bilan bir xil: **keystore.yml** ni `.github/workflows/keystore.yml` qilib qo'shing →
Actions → **Imzo kaliti yaratish (bir marta)** → parol → Artifacts → `release.jks.b64` →
Settings → Secrets → `KEYSTORE_BASE64` va `KEYSTORE_PASSWORD`. Kuryer kalitini ham ishlatsa bo'ladi
(o'sha ikki secret'ni shu repozitoriyga ham qo'shing). `release.jks` ni yo'qotmang.
