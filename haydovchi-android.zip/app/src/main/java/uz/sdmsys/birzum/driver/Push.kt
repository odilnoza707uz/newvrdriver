package uz.sdmsys.birzum.driver

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Push {
    /**
     * Telefonning Firebase tokenini serverga yuboradi (haydovchi tizimga kirgan bo'lishi kerak).
     * Orqa oqimda chaqiring. force=false bo'lsa, o'zgarmagan token qayta yuborilmaydi.
     */
    fun registerToken(ctx: Context, force: Boolean = true) {
        try {
            var t = Prefs.token(ctx)
            if (t.isEmpty()) {
                t = Tasks.await(FirebaseMessaging.getInstance().token, 20, TimeUnit.SECONDS)
                Prefs.setToken(ctx, t)
            }
            if (!force && Prefs.tokenSent(ctx) == t) return
            val r = Net.call(ctx, "fcm_token", JSONObject().put("token", t).put("quiet", true))
            if (r != null && r.json?.optBoolean("ok") == true) Prefs.setTokenSent(ctx, t)
        } catch (e: Exception) {
            // keyingi ochilishda qayta uriniladi
        }
    }
}
