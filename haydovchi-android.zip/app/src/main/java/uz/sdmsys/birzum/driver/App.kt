package uz.sdmsys.birzum.driver

import android.app.Application

class App : Application() {
    companion object {
        /** Ilova ekranda ochiq turganda signalni panelning o'zi beradi (ikki marta chalinmasligi uchun) */
        @Volatile
        var visible = false
    }

    override fun onCreate() {
        super.onCreate()
        Notif.createChannels(this)
    }
}
