package uz.sdmsys.birzum.driver

import android.content.Context

/** Kichik sozlamalar ombori (haydovchi ilovasi): push tokeni, kirgan-kirmaganligi, sessiya cookie'si */
object Prefs {
    private const val FILE = "bz_driver"

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun token(c: Context): String = sp(c).getString("fcm_token", "") ?: ""
    fun setToken(c: Context, v: String) = sp(c).edit().putString("fcm_token", v).apply()

    fun tokenSent(c: Context): String = sp(c).getString("fcm_sent", "") ?: ""
    fun setTokenSent(c: Context, v: String) = sp(c).edit().putString("fcm_sent", v).apply()

    fun loggedIn(c: Context): Boolean = sp(c).getBoolean("logged_in", false)
    fun setLoggedIn(c: Context, v: Boolean) = sp(c).edit().putBoolean("logged_in", v).apply()

    fun cookie(c: Context): String = sp(c).getString("cookie", "") ?: ""
    fun setCookie(c: Context, v: String) = sp(c).edit().putString("cookie", v).apply()

    /** Haydovchi ilovasi faqat taksi panelini ochadi: sayt/t/. Fon so'rovlari ham t/api.php ga boradi */
    fun panel(c: Context): String = "t/"

    fun oemDone(c: Context): Boolean = sp(c).getBoolean("oem_done", false)
    fun setOemDone(c: Context, v: Boolean) = sp(c).edit().putBoolean("oem_done", v).apply()
}
