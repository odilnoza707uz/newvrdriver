package uz.sdmsys.birzum.driver

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Serverdan keladigan push (faqat "data" xabar). Ilova yopiq bo'lsa ham shu yerga keladi.
 * Server yuboradigan maydonlar: title, body, type (order_ready | info | test), order
 */
class FcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        Prefs.setToken(this, token)
        if (Prefs.loggedIn(this)) {
            val app = applicationContext
            Thread { Push.registerToken(app, force = true) }.start()
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val d = message.data
        val type = d["type"] ?: "order_ready"
        val title = d["title"] ?: getString(R.string.new_order)
        val body = d["body"] ?: ""

        when (type) {
            "order_taken", "stop" -> AlarmService.stop(this)
            "test" -> {
                // Admin paneldagi "Test push": ilova ochiq bo'lsa ham ko'rinsin
                if (App.visible) Notif.info(this, getString(R.string.test_title), getString(R.string.test_text))
                else Alarm.trigger(this, title, body.ifEmpty { getString(R.string.test_text) })
            }
            // Oddiy xabar (hisob to'ldirildi, bekor qilindi va h.k.) — sirenasiz bildirishnoma
            "info" -> Notif.info(this, title, body)
            else -> {
                // Yangi buyurtma: ilova ochiq bo'lsa, signalni panelning o'zi beradi
                if (!App.visible) Alarm.trigger(this, title, body)
            }
        }
    }
}
